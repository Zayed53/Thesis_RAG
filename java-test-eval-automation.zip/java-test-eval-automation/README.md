# Java Unit Test Automation with Python

## 🚀 Quick Start
1. Place your Java files in `src/`
2. Place `junit-platform-console-standalone-*.jar` in `lib/`
3. Run:
```bash
cd scripts
python run_tests.py
```
4. See test reports in `reports/`

## 📦 Requirements
- Python 3.x
- Java JDK 11+