package servise.menu.inter;

public interface MenuLoginServiceInter extends MenuService{
}
