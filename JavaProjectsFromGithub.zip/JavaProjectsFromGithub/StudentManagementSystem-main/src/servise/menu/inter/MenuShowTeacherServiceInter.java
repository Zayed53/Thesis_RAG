package servise.menu.inter;

public interface MenuShowTeacherServiceInter extends MenuService {
}
