package servise.menu.inter;

public interface MenuAddTeacherServiceInter extends MenuService{
}
