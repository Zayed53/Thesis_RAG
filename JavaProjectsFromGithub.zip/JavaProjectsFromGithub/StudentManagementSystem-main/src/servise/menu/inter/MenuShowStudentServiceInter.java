package servise.menu.inter;

public interface MenuShowStudentServiceInter extends MenuService{
}
