package servise.menu.inter;

public interface MenuRegisterServiceInter extends MenuService{
}
