package servise.menu.inter;

public interface MenuAddStudentServiceInter extends MenuService{
}
