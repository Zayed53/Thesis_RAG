package servise.menu.inter;

public interface MenuService {
    void process();
}
