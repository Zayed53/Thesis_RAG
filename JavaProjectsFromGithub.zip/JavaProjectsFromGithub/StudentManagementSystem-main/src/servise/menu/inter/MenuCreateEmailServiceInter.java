package servise.menu.inter;

public interface MenuCreateEmailServiceInter extends MenuService{
}
