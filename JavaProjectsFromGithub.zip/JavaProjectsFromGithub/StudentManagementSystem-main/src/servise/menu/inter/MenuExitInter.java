package servise.menu.inter;

public interface MenuExitInter extends MenuService{
}
