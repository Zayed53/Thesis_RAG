# Guess The Number - A mini Java Project

It is a mini java project that I created where the program will create a random integer number that will be between 1 to 100 and the user will have to guess the number.

## Source

[Youtube Video Link](https://youtu.be/UmnCZ7-9yDY?list=PL8SyweqoPruaS43YjsBOXKaz0-sAIGAY9&t=6979)