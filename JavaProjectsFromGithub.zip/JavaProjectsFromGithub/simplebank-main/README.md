# simplebank
## Simple banking project using concept of
+ BASIC JAVA,
+ OOP, 
+ ENCAPSULATION, 
+ CONSTRUCTOR ,
+ ARRAYLIST ,

Here the link to run this program :

 👉 https://onlinegdb.com/2i8etXxkd
 
 
 


