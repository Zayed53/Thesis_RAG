# Stop-Watch
A beginner JAVA project to measure time-intervals...!!

## Description
A very basic stop watch project with play-pause-resume and lapping features.
The time measured can be saved in external files for future reference.
Also shows current date-time.
