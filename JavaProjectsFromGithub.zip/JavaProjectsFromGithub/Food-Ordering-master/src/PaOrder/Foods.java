package PaOrder;

public class Foods {
	
 String Types_Of_Foods[] = {"","1.Seafood and Fishes",
                               "2.Meat and Grills",
                               "3.Pizza",
                               "4.Sushi and Rolls",};


 String Seafood_Fish[] =   {"","1.Okoy-Okoy            ... P 100.00", 
                               "2.Fisharon             ... P 75.00", 
                               "3.Ginataang Hipon      ... P 100.00", 
                               "4.King Crab Dishes     ... P 125.00", 
                               "5.Squid Sisig          ... P 95.00"};

 String Meat_Grills[] =    {"","1.Korean BBQ           ... P 100.00",
                               "2.Mixed Grills         ... P 65.00", 
                               "3.Schlachteplatte      ... P 85.00", 
                               "4.Seswaa               ... P 75.00", 
                               "5.Fricassee            ... P 100.00"};

 String Pizza[]  =         {"","1.Neopolitan Pizza     ... P 100.00", 
                               "2.Chicago Pizza        ... P 100.00", 
                               "3.New York Style Pizza ... P 100.00", 
                               "4.Sicilian Pizza       ... P 100.00", 
                               "5.Detroit Pizza        ... P 100.00"};

 String Sushi_Rolls[] =    {"","1.Tuna Roll            ... P 85.00", 
                               "2.Octopus              ... P 85.00", 
                               "3.Yellowtail Roll      ... P 95.00", 
                               "4.Bluefin Tuna         ... P 110.00", 
                               "5.Vegetable Roll       ... P 70.00"};

 int Seafood_Fish_Price[] = {0, 100, 75, 100, 125, 95};
 int Meat_Grills_Price[]  = {0, 100, 65, 85, 75, 100};
 int Pizza_Price[] = {0, 100, 100, 100, 100, 100};
 int Sushi_Rolls_Price[] = {0, 85, 85, 95, 110, 70};


}
